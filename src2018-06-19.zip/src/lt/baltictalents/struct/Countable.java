package lt.baltictalents.struct;

public interface Countable {
  int size();
}
