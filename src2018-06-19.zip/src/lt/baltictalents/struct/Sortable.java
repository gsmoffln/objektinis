package lt.baltictalents.struct;

public interface Sortable<T> {
  Collection<T> sort();
}
