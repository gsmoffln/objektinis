package lt.baltictalents.struct;

public interface Set extends Collection{}
