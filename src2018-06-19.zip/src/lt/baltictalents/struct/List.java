package lt.baltictalents.struct;

import java.util.Iterator;

public interface List<T> extends Collection<T>, Countable, Sortable<T> {}

